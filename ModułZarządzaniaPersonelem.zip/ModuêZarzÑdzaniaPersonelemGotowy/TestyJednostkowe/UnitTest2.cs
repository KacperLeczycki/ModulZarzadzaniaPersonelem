﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ModułZarządzaniaPersonelem;

namespace TestyJednostkowe
{
    [TestClass]
    class UnitTest2
    {

    }
}
