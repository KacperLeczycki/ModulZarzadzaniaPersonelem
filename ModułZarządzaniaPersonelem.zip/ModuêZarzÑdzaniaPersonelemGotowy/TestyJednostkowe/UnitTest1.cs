using Microsoft.VisualStudio.TestTools.UnitTesting;
using Modu�Zarz�dzaniaPersonelem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace TestyJednostkowe
{
    [TestClass]
    public class Task
    {
        private string nameTask;

        private string description;

        private int task_ID;

        public int Task_ID { get => task_ID; }

        public string NameTask
        {
            get
            {
                return nameTask;
            }
            set
            {
                if (value != null && value is string)
                {
                    nameTask = value;
                }
                else
                {
                    return;
                }
            }
        }
        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                if (value != null && value is string)
                {
                    description = value;
                }
                else
                {
                    return;

                }
            }
        }


        
        [TestMethod]
        public void ADDTASK()
        {
            
            string a = "Sprz�tanie sali";
            string b = "Sprz�tanie sali nr 5";

            Task t = new Task();

            var aa = new string(a.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());
            var bb = new string(b.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());

            if (a == aa && b == bb && a != b && a != null && b != null && a != string.Empty && b != string.Empty)
            {
               
                t.nameTask = a;
                t.description = b;
               
            }
            Assert.IsNotNull(t.nameTask, "Uzupe�nij nazw� zadania");
            Assert.IsNotNull(t.description, "Uzupe�nij opis zadania");
        }

        [TestMethod]
        public void ADDTASK2()
        {

            string a = "";
            string b = "Sprz�tanie sali nr 5";

            Task t = new Task();

            var aa = new string(a.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());
            var bb = new string(b.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());

            if (a == aa && b == bb && a != b && a != null && b != null && a != string.Empty && b != string.Empty)
            {
                
                t.nameTask = a;
                t.description = b;
             
            }
            Assert.IsNotNull(t.nameTask, "Uzupe�nij nazw� zadania");
            Assert.IsNotNull(t.description, "Uzupe�nij opis zadania");



        }

        [TestMethod]
        public void ADDTASK3()
        {

            string a = "Sprz�tanie sali";
            string b = "";

            Task t = new Task();

            var aa = new string(a.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());
            var bb = new string(b.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());

            if (a == aa && b == bb && a != b && a != null && b != null && a != string.Empty && b != string.Empty)
            {

                t.nameTask = a;
                t.description = b;

            }

            Assert.IsNotNull(t.description, "Uzupe�nij opis zadania");
            Assert.IsNotNull(t.nameTask);
            
            
            
        }

        [TestMethod]
        public void ADDTASK4()
        {

            string a = "%$##;";
            string b = "Sprz�tanie sali nr 5";

            Task t = new Task();

            var aa = new string(a.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());
            var bb = new string(b.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());

            if (a == aa && b == bb && a != b && a != null && b != null && a != string.Empty && b != string.Empty)
            {

                t.nameTask = a;
                t.description = b;

            }
            Assert.IsNotNull(t.nameTask, "Z�e znaki w nazwie zadania");
            Assert.IsNotNull(t.description);
            

        }

        [TestMethod]
        public void ADDTASK5()
        {

            string a = "Sprz�tanie sali";
            string b = "%$##;";

            Task t = new Task();

            var aa = new string(a.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());
            var bb = new string(b.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());

            if (a == aa && b == bb && a != b && a != null && b != null && a != string.Empty && b != string.Empty)
            {

                t.nameTask = a;
                t.description = b;

            }

            Assert.IsNotNull(t.description, "Z�e znaki w opisie zadania");
            Assert.IsNotNull(t.nameTask);

        }

        [TestMethod]
        public void MODIFYTASK()
        {
            string a = "Sprz�tanie sali";
            string b = "Sprz�tanie sali nr 5";
            int i = 1;

            Task t = new Task();

            var aa = new string(a.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());
            var bb = new string(b.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());

            if (a == aa && b == bb && a != b && a != null && b != null && a != string.Empty && b != string.Empty)
            {               
                t.nameTask = a;
                t.description = b;
                t.task_ID = i;               
            }
            Assert.IsNotNull(t.nameTask);
            Assert.IsNotNull(t.description);
            Assert.IsNotNull(t.task_ID);

        }

        [TestMethod]
        public void MODIFYTASK2()
        {
            string a = ";';%^$";
            string b = "Sprz�tanie sali nr 5";
            int i = 1;

            Task t = new Task();

            var aa = new string(a.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());
            var bb = new string(b.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());

            if (a == aa && b == bb && a != b && a != null && b != null && a != string.Empty && b != string.Empty)
            {
                t.nameTask = a;
                t.description = b;
                t.task_ID = i;
            }
            Assert.IsNotNull(t.nameTask, "Problem z modyfikacj�, u�ytko znak�w specjalnych");
            Assert.IsNotNull(t.description);
            Assert.IsNotNull(t.task_ID);

        }

        [TestMethod]
        public void MODIFYTASK3()
        {
            string a = "Sprz�tanie sali";
            string b = "^(%&*";
            int i = 1;

            Task t = new Task();

            var aa = new string(a.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());
            var bb = new string(b.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());

            if (a == aa && b == bb && a != b && a != null && b != null && a != string.Empty && b != string.Empty)
            {
                t.nameTask = a;
                t.description = b;
                t.task_ID = i;
            }
            Assert.IsNotNull(t.description, "Problem z modyfikacj�, u�ytko znak�w specjalnych");
            Assert.IsNotNull(t.nameTask);
            Assert.IsNotNull(t.task_ID);

        }

        [TestMethod]
        public void MODIFYTASK4()
        {
            string a = "";
            string b = "Sprz�tanie sali nr 5";
            int i = 1;

            Task t = new Task();

            var aa = new string(a.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());
            var bb = new string(b.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());

            if (a == aa && b == bb && a != b && a != null && b != null && a != string.Empty && b != string.Empty)
            {
                t.nameTask = a;
                t.description = b;
                t.task_ID = i;
            }
            Assert.IsNotNull(t.nameTask, "Problem z modyfikacj�, wyst�puj� puste pola");
            Assert.IsNotNull(t.description);
            Assert.IsNotNull(t.task_ID);

        }

        [TestMethod]
        public void MODIFYTASK5()
        {
            string a = "Sprz�tanie sali";
            string b = "";
            int i = 1;

            Task t = new Task();

            var aa = new string(a.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());
            var bb = new string(b.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());

            if (a == aa && b == bb && a != b && a != null && b != null && a != string.Empty && b != string.Empty)
            {
                t.nameTask = a;
                t.description = b;
                t.task_ID = i;
            }
            Assert.IsNotNull(t.description, "Problem z modyfikacj�, wyst�puj� puste pola");
            Assert.IsNotNull(t.nameTask);
            Assert.IsNotNull(t.task_ID);

        }

    }
}
