﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace ModułZarządzaniaPersonelem
{
    class Task
    {

        private string nameTask;

        private string description;

        private int task_ID;

        public int Task_ID { get => task_ID; }

        public string NameTask
        {
            get
            {
                return nameTask;
            }
            set
            {
                if (value != null && value is String)
                {
                    nameTask = value;
                }
                else
                {
                    MessageBox.Show("Uzupełnij nazwę zadania");
                    return;
                }
            }
        }
        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                if (value != null && value is String)
                {
                    description = value;
                }
                else
                {
                    MessageBox.Show("Uzupełnij opis");
                    return;

                }
            }
        }
        /*public Task(int task_ID, string nameTask, string description)
        {
            this.task_ID = task_ID;
            this.nameTask = nameTask;
            this.description = description;
        }
        */
        public void ADDTASK(string nameTask, string description)
        {

            string a = nameTask;
            string b = description;

            var aa = new string(a.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());
            var bb = new string(b.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());

            if (a == aa && b == bb && a != b && a != null && b != null && a != string.Empty && b != string.Empty)
            {
                Task t = new Task();
                t.nameTask = a;
                t.description = b;
                AddTask(t.nameTask, t.description);
            }
        }


        public void MODIFYTASK(string nameTask, string description, int task_ID)
        {
            string a = nameTask;
            string b = description;
            int i = task_ID;

            var aa = new string(a.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());
            var bb = new string(b.Where(c => Char.IsLetterOrDigit(c)
                                                        || Char.IsWhiteSpace(c)).ToArray());

            if (a == aa && b == bb && a != b && a != null && b != null && a != string.Empty && b != string.Empty)
            {
                Task t = new Task();
                t.nameTask = a;
                t.description = b;
                t.task_ID = i;
                update(t.nameTask, t.description, t.task_ID);
            }
        }

        void AddTask(string nameTask, string description)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString))
            {
                try
                {
                    string query = "if (not exists(select * from [Task] where nameTask = @nameTask AND description = @description)) " +
                         "begin insert into [Task] (nameTask, description) values(@nameTask, @description) PRINT 'Dodano nowe zadanie' END ELSE PRINT 'Podane zadanie już istnieje'";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@nameTask", nameTask);
                        cmd.Parameters.AddWithValue("@description", description);
                        con.Open();
                        con.InfoMessage += respondeMessage;
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Niepowodzenie " + e.ToString());
                }
            }
        }

        void update(string nameTask, string description, int task_ID)
        {

            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString))
            {
                try
                {
                    string query1 = "if (not exists(select * from [Task] where nameTask = @nameTask AND description = @description)) " +
                        "begin update[Task] SET nameTask = @nameTask, " +
                        "description = @description where task_ID= @task_ID PRINT 'Zaktualizowano zadanie' end else" +
                        " PRINT 'Podane zadanie już istnieje'";

                    using (SqlCommand cmd = new SqlCommand(query1, con))
                    {
                        cmd.Parameters.AddWithValue("@nameTask", nameTask);
                        cmd.Parameters.AddWithValue("@description", description);
                        cmd.Parameters.AddWithValue("@task_ID", task_ID);
                        con.Open();
                        con.InfoMessage += respondeMessage;
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "Niepowodzenie");
                }
            }
        }

        void respondeMessage(object sender, SqlInfoMessageEventArgs e)
        {
            var outputFromQuery = e.Message;
            MessageBox.Show(outputFromQuery.ToString());
        }



        public override string ToString()
        {
            return description;
        }
    }
}