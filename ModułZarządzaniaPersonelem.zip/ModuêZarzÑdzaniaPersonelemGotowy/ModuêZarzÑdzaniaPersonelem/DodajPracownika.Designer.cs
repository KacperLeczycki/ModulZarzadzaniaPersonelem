﻿namespace ModułZarządzaniaPersonelem
{
    partial class DodajPracownika
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelImięDodajPracownika = new System.Windows.Forms.Label();
            this.labelNazwiskoDodajPracownika = new System.Windows.Forms.Label();
            this.labelLoginDodajPracownika = new System.Windows.Forms.Label();
            this.labelHasłoDodajPracownika = new System.Windows.Forms.Label();
            this.labelKodDodajPracownika = new System.Windows.Forms.Label();
            this.labelPensjaDodajPracownika = new System.Windows.Forms.Label();
            this.labelStawkaDodajPracownika = new System.Windows.Forms.Label();
            this.labelUprawnieniaDodajPracownika = new System.Windows.Forms.Label();
            this.textBoxImięDodajPracownika = new System.Windows.Forms.TextBox();
            this.textBoxNazwiskoDodajPracownika = new System.Windows.Forms.TextBox();
            this.textBoxLoginDodajPracownika = new System.Windows.Forms.TextBox();
            this.textBoxHasłoDodajPracownika = new System.Windows.Forms.TextBox();
            this.textBoxKodDodajPracownika = new System.Windows.Forms.TextBox();
            this.numericUpDownPensjaDodajPracownika = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownStawkaDodajPracownika = new System.Windows.Forms.NumericUpDown();
            this.comboBoxUprawnieniaDodajPracownika = new System.Windows.Forms.ComboBox();
            this.buttonZapiszDodajPracownika = new System.Windows.Forms.Button();
            this.buttonWróć = new System.Windows.Forms.Button();
            this.labelPotwierdzHaslo = new System.Windows.Forms.Label();
            this.textBoxPotwierdzHaslo = new System.Windows.Forms.TextBox();
            this.checkBoxPokazHaslo = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPensjaDodajPracownika)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownStawkaDodajPracownika)).BeginInit();
            this.SuspendLayout();
            // 
            // labelImięDodajPracownika
            // 
            this.labelImięDodajPracownika.AutoSize = true;
            this.labelImięDodajPracownika.Location = new System.Drawing.Point(131, 9);
            this.labelImięDodajPracownika.Name = "labelImięDodajPracownika";
            this.labelImięDodajPracownika.Size = new System.Drawing.Size(26, 13);
            this.labelImięDodajPracownika.TabIndex = 0;
            this.labelImięDodajPracownika.Text = "Imię";
            // 
            // labelNazwiskoDodajPracownika
            // 
            this.labelNazwiskoDodajPracownika.AutoSize = true;
            this.labelNazwiskoDodajPracownika.Location = new System.Drawing.Point(117, 65);
            this.labelNazwiskoDodajPracownika.Name = "labelNazwiskoDodajPracownika";
            this.labelNazwiskoDodajPracownika.Size = new System.Drawing.Size(53, 13);
            this.labelNazwiskoDodajPracownika.TabIndex = 1;
            this.labelNazwiskoDodajPracownika.Text = "Nazwisko";
            // 
            // labelLoginDodajPracownika
            // 
            this.labelLoginDodajPracownika.AutoSize = true;
            this.labelLoginDodajPracownika.Location = new System.Drawing.Point(124, 118);
            this.labelLoginDodajPracownika.Name = "labelLoginDodajPracownika";
            this.labelLoginDodajPracownika.Size = new System.Drawing.Size(33, 13);
            this.labelLoginDodajPracownika.TabIndex = 2;
            this.labelLoginDodajPracownika.Text = "Login";
            // 
            // labelHasłoDodajPracownika
            // 
            this.labelHasłoDodajPracownika.AutoSize = true;
            this.labelHasłoDodajPracownika.Location = new System.Drawing.Point(124, 170);
            this.labelHasłoDodajPracownika.Name = "labelHasłoDodajPracownika";
            this.labelHasłoDodajPracownika.Size = new System.Drawing.Size(36, 13);
            this.labelHasłoDodajPracownika.TabIndex = 3;
            this.labelHasłoDodajPracownika.Text = "Hasło";
            // 
            // labelKodDodajPracownika
            // 
            this.labelKodDodajPracownika.AutoSize = true;
            this.labelKodDodajPracownika.Location = new System.Drawing.Point(124, 269);
            this.labelKodDodajPracownika.Name = "labelKodDodajPracownika";
            this.labelKodDodajPracownika.Size = new System.Drawing.Size(26, 13);
            this.labelKodDodajPracownika.TabIndex = 4;
            this.labelKodDodajPracownika.Text = "Kod";
            // 
            // labelPensjaDodajPracownika
            // 
            this.labelPensjaDodajPracownika.AutoSize = true;
            this.labelPensjaDodajPracownika.Location = new System.Drawing.Point(121, 321);
            this.labelPensjaDodajPracownika.Name = "labelPensjaDodajPracownika";
            this.labelPensjaDodajPracownika.Size = new System.Drawing.Size(39, 13);
            this.labelPensjaDodajPracownika.TabIndex = 5;
            this.labelPensjaDodajPracownika.Text = "Pensja";
            // 
            // labelStawkaDodajPracownika
            // 
            this.labelStawkaDodajPracownika.AutoSize = true;
            this.labelStawkaDodajPracownika.Location = new System.Drawing.Point(92, 373);
            this.labelStawkaDodajPracownika.Name = "labelStawkaDodajPracownika";
            this.labelStawkaDodajPracownika.Size = new System.Drawing.Size(99, 13);
            this.labelStawkaDodajPracownika.TabIndex = 6;
            this.labelStawkaDodajPracownika.Text = "Stawka Godzinowa";
            // 
            // labelUprawnieniaDodajPracownika
            // 
            this.labelUprawnieniaDodajPracownika.AutoSize = true;
            this.labelUprawnieniaDodajPracownika.Location = new System.Drawing.Point(109, 432);
            this.labelUprawnieniaDodajPracownika.Name = "labelUprawnieniaDodajPracownika";
            this.labelUprawnieniaDodajPracownika.Size = new System.Drawing.Size(66, 13);
            this.labelUprawnieniaDodajPracownika.TabIndex = 7;
            this.labelUprawnieniaDodajPracownika.Text = "Uprawnienia";
            // 
            // textBoxImięDodajPracownika
            // 
            this.textBoxImięDodajPracownika.Location = new System.Drawing.Point(80, 25);
            this.textBoxImięDodajPracownika.Name = "textBoxImięDodajPracownika";
            this.textBoxImięDodajPracownika.Size = new System.Drawing.Size(121, 20);
            this.textBoxImięDodajPracownika.TabIndex = 8;
            this.textBoxImięDodajPracownika.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxImięDodajPracownika_KeyPress);
            // 
            // textBoxNazwiskoDodajPracownika
            // 
            this.textBoxNazwiskoDodajPracownika.Location = new System.Drawing.Point(80, 81);
            this.textBoxNazwiskoDodajPracownika.Name = "textBoxNazwiskoDodajPracownika";
            this.textBoxNazwiskoDodajPracownika.Size = new System.Drawing.Size(121, 20);
            this.textBoxNazwiskoDodajPracownika.TabIndex = 9;
            this.textBoxNazwiskoDodajPracownika.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxNazwiskoDodajPracownika_KeyPress);
            // 
            // textBoxLoginDodajPracownika
            // 
            this.textBoxLoginDodajPracownika.Location = new System.Drawing.Point(80, 134);
            this.textBoxLoginDodajPracownika.MaxLength = 30;
            this.textBoxLoginDodajPracownika.Name = "textBoxLoginDodajPracownika";
            this.textBoxLoginDodajPracownika.Size = new System.Drawing.Size(121, 20);
            this.textBoxLoginDodajPracownika.TabIndex = 10;
            this.textBoxLoginDodajPracownika.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxLoginDodajPracownika_KeyPress);
            // 
            // textBoxHasłoDodajPracownika
            // 
            this.textBoxHasłoDodajPracownika.Location = new System.Drawing.Point(80, 186);
            this.textBoxHasłoDodajPracownika.MaxLength = 30;
            this.textBoxHasłoDodajPracownika.Name = "textBoxHasłoDodajPracownika";
            this.textBoxHasłoDodajPracownika.PasswordChar = '*';
            this.textBoxHasłoDodajPracownika.Size = new System.Drawing.Size(121, 20);
            this.textBoxHasłoDodajPracownika.TabIndex = 11;
            this.textBoxHasłoDodajPracownika.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxHasłoDodajPracownika_KeyPress);
            // 
            // textBoxKodDodajPracownika
            // 
            this.textBoxKodDodajPracownika.Location = new System.Drawing.Point(80, 285);
            this.textBoxKodDodajPracownika.MaxLength = 30;
            this.textBoxKodDodajPracownika.Name = "textBoxKodDodajPracownika";
            this.textBoxKodDodajPracownika.Size = new System.Drawing.Size(121, 20);
            this.textBoxKodDodajPracownika.TabIndex = 12;
            this.textBoxKodDodajPracownika.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxKodDodajPracownika_KeyPress);
            // 
            // numericUpDownPensjaDodajPracownika
            // 
            this.numericUpDownPensjaDodajPracownika.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDownPensjaDodajPracownika.Location = new System.Drawing.Point(80, 337);
            this.numericUpDownPensjaDodajPracownika.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.numericUpDownPensjaDodajPracownika.Name = "numericUpDownPensjaDodajPracownika";
            this.numericUpDownPensjaDodajPracownika.Size = new System.Drawing.Size(121, 20);
            this.numericUpDownPensjaDodajPracownika.TabIndex = 13;
            // 
            // numericUpDownStawkaDodajPracownika
            // 
            this.numericUpDownStawkaDodajPracownika.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDownStawkaDodajPracownika.Location = new System.Drawing.Point(80, 389);
            this.numericUpDownStawkaDodajPracownika.Name = "numericUpDownStawkaDodajPracownika";
            this.numericUpDownStawkaDodajPracownika.Size = new System.Drawing.Size(121, 20);
            this.numericUpDownStawkaDodajPracownika.TabIndex = 14;
            // 
            // comboBoxUprawnieniaDodajPracownika
            // 
            this.comboBoxUprawnieniaDodajPracownika.FormattingEnabled = true;
            this.comboBoxUprawnieniaDodajPracownika.Items.AddRange(new object[] {
            "Uprzywilejowany",
            "Nieuprzywilejowany"});
            this.comboBoxUprawnieniaDodajPracownika.Location = new System.Drawing.Point(80, 458);
            this.comboBoxUprawnieniaDodajPracownika.Name = "comboBoxUprawnieniaDodajPracownika";
            this.comboBoxUprawnieniaDodajPracownika.Size = new System.Drawing.Size(121, 21);
            this.comboBoxUprawnieniaDodajPracownika.TabIndex = 15;
            this.comboBoxUprawnieniaDodajPracownika.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBoxUprawnieniaDodajPracownika_KeyPress);
            // 
            // buttonZapiszDodajPracownika
            // 
            this.buttonZapiszDodajPracownika.Location = new System.Drawing.Point(80, 505);
            this.buttonZapiszDodajPracownika.Name = "buttonZapiszDodajPracownika";
            this.buttonZapiszDodajPracownika.Size = new System.Drawing.Size(121, 23);
            this.buttonZapiszDodajPracownika.TabIndex = 16;
            this.buttonZapiszDodajPracownika.Text = "Zapisz";
            this.buttonZapiszDodajPracownika.UseVisualStyleBackColor = true;
            this.buttonZapiszDodajPracownika.Click += new System.EventHandler(this.buttonZapiszDodajPracownika_Click);
            // 
            // buttonWróć
            // 
            this.buttonWróć.Location = new System.Drawing.Point(80, 539);
            this.buttonWróć.Name = "buttonWróć";
            this.buttonWróć.Size = new System.Drawing.Size(121, 23);
            this.buttonWróć.TabIndex = 17;
            this.buttonWróć.Text = "Wróc";
            this.buttonWróć.UseVisualStyleBackColor = true;
            this.buttonWróć.Click += new System.EventHandler(this.buttonWróć_Click);
            // 
            // labelPotwierdzHaslo
            // 
            this.labelPotwierdzHaslo.AutoSize = true;
            this.labelPotwierdzHaslo.Location = new System.Drawing.Point(98, 217);
            this.labelPotwierdzHaslo.Name = "labelPotwierdzHaslo";
            this.labelPotwierdzHaslo.Size = new System.Drawing.Size(83, 13);
            this.labelPotwierdzHaslo.TabIndex = 18;
            this.labelPotwierdzHaslo.Text = "Potwierdź hasło";
            // 
            // textBoxPotwierdzHaslo
            // 
            this.textBoxPotwierdzHaslo.Location = new System.Drawing.Point(80, 240);
            this.textBoxPotwierdzHaslo.MaxLength = 30;
            this.textBoxPotwierdzHaslo.Name = "textBoxPotwierdzHaslo";
            this.textBoxPotwierdzHaslo.PasswordChar = '*';
            this.textBoxPotwierdzHaslo.Size = new System.Drawing.Size(121, 20);
            this.textBoxPotwierdzHaslo.TabIndex = 19;
            // 
            // checkBoxPokazHaslo
            // 
            this.checkBoxPokazHaslo.AutoSize = true;
            this.checkBoxPokazHaslo.Location = new System.Drawing.Point(213, 217);
            this.checkBoxPokazHaslo.Name = "checkBoxPokazHaslo";
            this.checkBoxPokazHaslo.Size = new System.Drawing.Size(86, 17);
            this.checkBoxPokazHaslo.TabIndex = 20;
            this.checkBoxPokazHaslo.Text = "Pokaż hasło";
            this.checkBoxPokazHaslo.UseVisualStyleBackColor = true;
            this.checkBoxPokazHaslo.CheckedChanged += new System.EventHandler(this.checkBoxPokazHaslo_CheckedChanged);
            // 
            // DodajPracownika
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(297, 585);
            this.Controls.Add(this.checkBoxPokazHaslo);
            this.Controls.Add(this.textBoxPotwierdzHaslo);
            this.Controls.Add(this.labelPotwierdzHaslo);
            this.Controls.Add(this.buttonWróć);
            this.Controls.Add(this.buttonZapiszDodajPracownika);
            this.Controls.Add(this.comboBoxUprawnieniaDodajPracownika);
            this.Controls.Add(this.numericUpDownStawkaDodajPracownika);
            this.Controls.Add(this.numericUpDownPensjaDodajPracownika);
            this.Controls.Add(this.textBoxKodDodajPracownika);
            this.Controls.Add(this.textBoxHasłoDodajPracownika);
            this.Controls.Add(this.textBoxLoginDodajPracownika);
            this.Controls.Add(this.textBoxNazwiskoDodajPracownika);
            this.Controls.Add(this.textBoxImięDodajPracownika);
            this.Controls.Add(this.labelUprawnieniaDodajPracownika);
            this.Controls.Add(this.labelStawkaDodajPracownika);
            this.Controls.Add(this.labelPensjaDodajPracownika);
            this.Controls.Add(this.labelKodDodajPracownika);
            this.Controls.Add(this.labelHasłoDodajPracownika);
            this.Controls.Add(this.labelLoginDodajPracownika);
            this.Controls.Add(this.labelNazwiskoDodajPracownika);
            this.Controls.Add(this.labelImięDodajPracownika);
            this.Name = "DodajPracownika";
            this.Text = "DodajPracownika";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DodajPracownika_FormClosing);
            this.Load += new System.EventHandler(this.DodajPracownika_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPensjaDodajPracownika)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownStawkaDodajPracownika)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelImięDodajPracownika;
        private System.Windows.Forms.Label labelNazwiskoDodajPracownika;
        private System.Windows.Forms.Label labelLoginDodajPracownika;
        private System.Windows.Forms.Label labelHasłoDodajPracownika;
        private System.Windows.Forms.Label labelKodDodajPracownika;
        private System.Windows.Forms.Label labelPensjaDodajPracownika;
        private System.Windows.Forms.Label labelStawkaDodajPracownika;
        private System.Windows.Forms.Label labelUprawnieniaDodajPracownika;
        private System.Windows.Forms.TextBox textBoxImięDodajPracownika;
        private System.Windows.Forms.TextBox textBoxNazwiskoDodajPracownika;
        private System.Windows.Forms.TextBox textBoxLoginDodajPracownika;
        private System.Windows.Forms.TextBox textBoxHasłoDodajPracownika;
        private System.Windows.Forms.TextBox textBoxKodDodajPracownika;
        private System.Windows.Forms.NumericUpDown numericUpDownPensjaDodajPracownika;
        private System.Windows.Forms.NumericUpDown numericUpDownStawkaDodajPracownika;
        private System.Windows.Forms.ComboBox comboBoxUprawnieniaDodajPracownika;
        private System.Windows.Forms.Button buttonZapiszDodajPracownika;
        private System.Windows.Forms.Button buttonWróć;
        private System.Windows.Forms.Label labelPotwierdzHaslo;
        private System.Windows.Forms.TextBox textBoxPotwierdzHaslo;
        private System.Windows.Forms.CheckBox checkBoxPokazHaslo;
    }
}