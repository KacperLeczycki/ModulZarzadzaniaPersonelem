﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using System.Configuration;

namespace ModułZarządzaniaPersonelem
{
    public partial class PanelMenadżera : Form
    {
        Task task;

        Thread th;

        public PanelMenadżera()
        {
            InitializeComponent();
        }

        private void buttonZapiszZadanie_Click(object sender, EventArgs e)
        {

            if (textBoxNazwa.Text != string.Empty && textBoxOpis.Text != string.Empty)
            {
                Task t = new Task(); 
                t.ADDTASK(textBoxNazwa.Text, textBoxOpis.Text);
            }
            else
            {
                MessageBox.Show("Uzupełnij informacje");
            }

            this.Validate();
            this.taskBindingSource.EndEdit();
            this.taskTableAdapter1.Update(this.modułZarządzaniaPersonelemDataSet1.Task);
            this.taskTableAdapter1.Fill(this.modułZarządzaniaPersonelemDataSet1.Task);
            textBoxNazwa.Clear();
            textBoxOpis.Clear();
            bindingNavigator1.Refresh();
        }
       
        void respondeMessage(object sender, SqlInfoMessageEventArgs e)
        {
            var outputFromQuery = e.Message;
            MessageBox.Show(outputFromQuery.ToString());            
        }

        private void buttonDodajPracownika_Click(object sender, EventArgs e)
        {

            this.Dispose();
            th = new Thread(openForm);
            th.Start();

        }

        private void openForm()
        {
                Application.Run(new DodajPracownika());
        }


        private void buttonEdytujPracownika_Click(object sender, EventArgs e)
        {

            this.Dispose();
            th = new Thread(openForm1);
            th.Start();

        }

        private void openForm1()
        {
            Application.Run(new EdycjaPracownika());
        }

        private void HarmonogramUprzywilejowany_Load(object sender, EventArgs e)
        {
            // TODO: Ten wiersz kodu wczytuje dane do tabeli 'modułZarządzaniaPersonelemDataSet1.Task' . Możesz go przenieść lub usunąć.
            this.taskTableAdapter1.Fill(this.modułZarządzaniaPersonelemDataSet1.Task);
            // TODO: Ten wiersz kodu wczytuje dane do tabeli 'modułZarządzaniaPersonelemDataSet.Task' . Możesz go przenieść lub usunąć.
            this.taskTableAdapter.Fill(this.modułZarządzaniaPersonelemDataSet.Task);

            DateTime n = DateTime.Now;
            labelData1.Text = (n.ToString("d"));

        }



        private void bindingNavigator1_RefreshItems(object sender, EventArgs e)
        {

        }

        private void buttonModyfikujZadanie_Click(object sender, EventArgs e)
        {
            if (textBoxIDZadania.Text != string.Empty && txtbNazwaZadania.Text != string.Empty && txtbOpisZadania.Text != string.Empty)
            {
                Task t = new Task();
                t.MODIFYTASK(txtbNazwaZadania.Text , txtbOpisZadania.Text , Convert.ToInt32(textBoxIDZadania.Text));
                this.Validate();
                this.taskBindingSource.EndEdit();
                this.taskTableAdapter1.Fill(this.modułZarządzaniaPersonelemDataSet1.Task);
            }
            else
            {
                MessageBox.Show("Nie można zaktualizować zadania bez wszystkich informacji");
                this.Dispose();
                th = new Thread(openForm5);
                th.Start();
            }

            
        }

        private void openForm5()
        {
            Application.Run(new PanelMenadżera());
        }
    

        private void textBoxNazwa_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '`' || e.KeyChar == '~' || e.KeyChar == '!' || e.KeyChar == '@' ||
                e.KeyChar == '#' || e.KeyChar == '$' || e.KeyChar == '%' || e.KeyChar == '^' ||
                e.KeyChar == '&' || e.KeyChar == '*' || e.KeyChar == '(' || e.KeyChar == ')' ||
                e.KeyChar == '-' || e.KeyChar == '_' || e.KeyChar == '=' || e.KeyChar == '+' ||
                e.KeyChar == '/' || e.KeyChar == '[' || e.KeyChar == '{' || e.KeyChar == ']' ||
                e.KeyChar == '}' || e.KeyChar == '|' || e.KeyChar == ';' || e.KeyChar == ':' ||
                e.KeyChar == '"' || e.KeyChar == ',' || e.KeyChar == '<' || e.KeyChar == '.' ||
                e.KeyChar == '>' || e.KeyChar == '?' )
            {
                e.Handled = true;
            }
        }

        private void textBoxOpis_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '`' || e.KeyChar == '~' || e.KeyChar == '!' || e.KeyChar == '@' ||
                e.KeyChar == '#' || e.KeyChar == '$' || e.KeyChar == '%' || e.KeyChar == '^' ||
                e.KeyChar == '&' || e.KeyChar == '*' || e.KeyChar == '(' || e.KeyChar == ')' ||
                e.KeyChar == '-' || e.KeyChar == '_' || e.KeyChar == '=' || e.KeyChar == '+' ||
                e.KeyChar == '/' || e.KeyChar == '[' || e.KeyChar == '{' || e.KeyChar == ']' ||
                e.KeyChar == '}' || e.KeyChar == '|' || e.KeyChar == ';' || e.KeyChar == ':' ||
                e.KeyChar == '"' || e.KeyChar == ',' || e.KeyChar == '<' || e.KeyChar == '.' ||
                e.KeyChar == '>' || e.KeyChar == '?' )
            {
                e.Handled = true;
            }
        }

        private void txtbNazwaZadania_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '`' || e.KeyChar == '~' || e.KeyChar == '!' || e.KeyChar == '@' ||
                e.KeyChar == '#' || e.KeyChar == '$' || e.KeyChar == '%' || e.KeyChar == '^' ||
                e.KeyChar == '&' || e.KeyChar == '*' || e.KeyChar == '(' || e.KeyChar == ')' ||
                e.KeyChar == '-' || e.KeyChar == '_' || e.KeyChar == '=' || e.KeyChar == '+' ||
                e.KeyChar == '/' || e.KeyChar == '[' || e.KeyChar == '{' || e.KeyChar == ']' ||
                e.KeyChar == '}' || e.KeyChar == '|' || e.KeyChar == ';' || e.KeyChar == ':' ||
                e.KeyChar == '"' || e.KeyChar == ',' || e.KeyChar == '<' || e.KeyChar == '.' ||
                e.KeyChar == '>' || e.KeyChar == '?' )
            {
                e.Handled = true;
            }
        }

        private void txtbOpisZadania_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '`' || e.KeyChar == '~' || e.KeyChar == '!' || e.KeyChar == '@' ||
                e.KeyChar == '#' || e.KeyChar == '$' || e.KeyChar == '%' || e.KeyChar == '^' ||
                e.KeyChar == '&' || e.KeyChar == '*' || e.KeyChar == '(' || e.KeyChar == ')' ||
                e.KeyChar == '-' || e.KeyChar == '_' || e.KeyChar == '=' || e.KeyChar == '+' ||
                e.KeyChar == '/' || e.KeyChar == '[' || e.KeyChar == '{' || e.KeyChar == ']' ||
                e.KeyChar == '}' || e.KeyChar == '|' || e.KeyChar == ';' || e.KeyChar == ':' ||
                e.KeyChar == '"' || e.KeyChar == ',' || e.KeyChar == '<' || e.KeyChar == '.' ||
                e.KeyChar == '>' || e.KeyChar == '?' )
            {
                e.Handled = true;
            }
        }

        private void buttonWyloguj_Click(object sender, EventArgs e)
        {
            this.Dispose();
            th = new Thread(openForm2);
            th.Start();
        }

        private void openForm2()
        {
            Application.Run(new Logowanie());
        }

        private void buttonPrzypisz_Click(object sender, EventArgs e)
        {
            this.Dispose();
            th = new Thread(openForm3);
            th.Start();
        }

        private void openForm3()
        {
            Application.Run(new PrzypiszZadanie());
        }

        private void buttonWyświetl_Click(object sender, EventArgs e)
        {
            this.Dispose();
            th = new Thread(openForm4);
            th.Start();
        }

        private void openForm4()
        {
            Application.Run(new WyświetlanieHarmonogramu());
        }

        private void PanelMenadżera_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                DialogResult res = MessageBox.Show("Czy na pewno chcesz zamknąć program?", "Zamykanie", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                {
                    if (res == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                        return;
                    }

                }
            }
        }
    }

}