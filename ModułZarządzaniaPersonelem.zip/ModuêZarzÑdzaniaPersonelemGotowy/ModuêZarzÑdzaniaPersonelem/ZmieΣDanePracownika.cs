﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using System.Configuration;

namespace ModułZarządzaniaPersonelem
{
    internal partial class ZmieńDanePracownika : Form
    {
        Thread th;

        User user;

        public ZmieńDanePracownika(User user)
        {
            InitializeComponent();
            this.user = user;
        }
        
        private void ZmieńDanePracownika_Load(object sender, EventArgs e)
        {
            textBoxImięDodajPracownika.Text = user.FirstName;
            textBoxNazwiskoDodajPracownika.Text = user.LastName;
            textBoxHasłoDodajPracownika.Text = user.PasswordHash;
            textBoxLoginDodajPracownika.Text = user.Login;
            textBoxKodDodajPracownika.Text = user.CodeHash;
            numericUpDownPensjaDodajPracownika.Value = user.BaseSalary;
            numericUpDownStawkaDodajPracownika.Value = user.HourlyRate;
            comboBoxUprawnieniaDodajPracownika.SelectedItem = user.Permission;
        }

        private void buttonZapiszDodajPracownika_Click(object sender, EventArgs e)
        {
            if (textBoxHasłoDodajPracownika.Text == textBoxPotwierdzHaslo.Text && textBoxHasłoDodajPracownika.Text.Length > 6)
            {
                user.FirstName = textBoxImięDodajPracownika.Text;
                user.LastName = textBoxNazwiskoDodajPracownika.Text;
                user.PasswordHash = textBoxHasłoDodajPracownika.Text;
                user.Login = textBoxLoginDodajPracownika.Text;
                user.CodeHash = textBoxKodDodajPracownika.Text;
                user.BaseSalary = numericUpDownPensjaDodajPracownika.Value;
                user.HourlyRate = numericUpDownStawkaDodajPracownika.Value;
                user.Permission = comboBoxUprawnieniaDodajPracownika.SelectedItem.ToString();
                DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Hasła nie są takie same lub podane hasło jest za krótkie");
            }
        }

        private void buttonAnuluj_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void openForm()
        {
            Application.Run(new EdycjaPracownika());
        }

        private void buttonUsuń_Click(object sender, EventArgs e)
        {
            if (textBoxImięDodajPracownika.Text != string.Empty && textBoxNazwiskoDodajPracownika.Text != string.Empty && textBoxHasłoDodajPracownika.Text != string.Empty
               && textBoxLoginDodajPracownika.Text != string.Empty && textBoxKodDodajPracownika.Text != string.Empty && numericUpDownPensjaDodajPracownika.Value > 0 &&
                numericUpDownStawkaDodajPracownika.Value > 0 && comboBoxUprawnieniaDodajPracownika.SelectedItem != null)
            {
                DeleteUser();
            }
            else
            {
                MessageBox.Show("Uzupełnij informacje");
            }
            buttonZapiszDodajPracownika.Enabled = false;

        }

        void DeleteUser()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString))
            {
                try
                {
                    string q = "if (exists(select * from [User] where user_ID = @user_ID)) begin delete " +
                        "from [User] where user_ID = @user_ID Print 'Usunięto' end else print 'Nie ma takiego pracownika'";

                    using (SqlCommand cmd = new SqlCommand(q, con))
                    {
                        cmd.Parameters.AddWithValue("@user_ID", user.User_Id);
                        con.Open();
                        con.InfoMessage += respondeMessage;
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Niepowodzenie " + e.ToString());
                }
            }
        }

        void respondeMessage(object sender, SqlInfoMessageEventArgs e)
        {
            var outputFromQuery = e.Message;
            MessageBox.Show(outputFromQuery.ToString());
        }

        private void textBoxImięDodajPracownika_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '`' || e.KeyChar == '~' || e.KeyChar == '!' || e.KeyChar == '@' ||
                e.KeyChar == '#' || e.KeyChar == '$' || e.KeyChar == '%' || e.KeyChar == '^' ||
                e.KeyChar == '&' || e.KeyChar == '*' || e.KeyChar == '(' || e.KeyChar == ')' ||
                e.KeyChar == '-' || e.KeyChar == '_' || e.KeyChar == '=' || e.KeyChar == '+' ||
                e.KeyChar == '/' || e.KeyChar == '[' || e.KeyChar == '{' || e.KeyChar == ']' ||
                e.KeyChar == '}' || e.KeyChar == '|' || e.KeyChar == ';' || e.KeyChar == ':' ||
                e.KeyChar == '"' || e.KeyChar == ',' || e.KeyChar == '<' || e.KeyChar == '.' ||
                e.KeyChar == '>' || e.KeyChar == '?' || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = true;
            }

            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || e.KeyChar == '4' ||
               e.KeyChar == '5' || e.KeyChar == '6' || e.KeyChar == '7' || e.KeyChar == '8'
               || e.KeyChar == '9' || e.KeyChar == '0')
            {
                e.Handled = true;
            }
        }

        private void textBoxNazwiskoDodajPracownika_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '`' || e.KeyChar == '~' || e.KeyChar == '!' || e.KeyChar == '@' ||
                e.KeyChar == '#' || e.KeyChar == '$' || e.KeyChar == '%' || e.KeyChar == '^' ||
                e.KeyChar == '&' || e.KeyChar == '*' || e.KeyChar == '(' || e.KeyChar == ')' ||
                e.KeyChar == '-' || e.KeyChar == '_' || e.KeyChar == '=' || e.KeyChar == '+' ||
                e.KeyChar == '/' || e.KeyChar == '[' || e.KeyChar == '{' || e.KeyChar == ']' ||
                e.KeyChar == '}' || e.KeyChar == '|' || e.KeyChar == ';' || e.KeyChar == ':' ||
                e.KeyChar == '"' || e.KeyChar == ',' || e.KeyChar == '<' || e.KeyChar == '.' ||
                e.KeyChar == '>' || e.KeyChar == '?' || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = true;
            }

            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || e.KeyChar == '4' ||
               e.KeyChar == '5' || e.KeyChar == '6' || e.KeyChar == '7' || e.KeyChar == '8'
               || e.KeyChar == '9' || e.KeyChar == '0')
            {
                e.Handled = true;
            }
        }

        private void textBoxLoginDodajPracownika_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Space)
            {
                e.Handled = true;
            }
        }

        private void textBoxHasłoDodajPracownika_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Space)
            {
                e.Handled = true;
            }
        }

        private void textBoxKodDodajPracownika_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Space)
            {
                e.Handled = true;
            }
        }

        private void comboBoxUprawnieniaDodajPracownika_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '`' || e.KeyChar == '~' || e.KeyChar == '!' || e.KeyChar == '@' ||
                e.KeyChar == '#' || e.KeyChar == '$' || e.KeyChar == '%' || e.KeyChar == '^' ||
                e.KeyChar == '&' || e.KeyChar == '*' || e.KeyChar == '(' || e.KeyChar == ')' ||
                e.KeyChar == '-' || e.KeyChar == '_' || e.KeyChar == '=' || e.KeyChar == '+' ||
                e.KeyChar == '/' || e.KeyChar == '[' || e.KeyChar == '{' || e.KeyChar == ']' ||
                e.KeyChar == '}' || e.KeyChar == '|' || e.KeyChar == ';' || e.KeyChar == ':' ||
                e.KeyChar == '"' || e.KeyChar == ',' || e.KeyChar == '<' || e.KeyChar == '.' ||
                e.KeyChar == '>' || e.KeyChar == '?' || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = true;
            }

            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || e.KeyChar == '4' ||
               e.KeyChar == '5' || e.KeyChar == '6' || e.KeyChar == '7' || e.KeyChar == '8'
               || e.KeyChar == '9' || e.KeyChar == '0')
            {
                e.Handled = true;
            }
        }

        private void checkBoxPokazHaslo_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxPokazHaslo.Checked == true)
            {
                textBoxHasłoDodajPracownika.PasswordChar = '\0';
                textBoxPotwierdzHaslo.PasswordChar = '\0';
            }
            else
            {
                textBoxHasłoDodajPracownika.PasswordChar = '*';
                textBoxPotwierdzHaslo.PasswordChar = '*';
            }
        }

        private void ZmieńDanePracownika_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                DialogResult res = MessageBox.Show("Czy na pewno chcesz zamknąć program?", "Zamykanie", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                {
                    if (res == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                        return;
                    }

                }
            }
        }
    }
}
