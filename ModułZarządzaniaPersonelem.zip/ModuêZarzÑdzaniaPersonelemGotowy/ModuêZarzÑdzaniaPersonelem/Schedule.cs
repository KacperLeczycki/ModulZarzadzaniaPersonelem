﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ModułZarządzaniaPersonelem
{
    class Schedule
    {
        int schedule_ID, user_ID;
        string task_ID, scheduleStatus_ID;

        DateTime dateSchedule;

        TimeSpan hourOfExecution;

        public int Schedule_ID { get => schedule_ID; }

        public int User_ID
        {
            get
            {
                return user_ID;
            }
            set
            {
                if (value > 0)
                {
                    user_ID = value;
                }
                else
                {
                    MessageBox.Show("Wybierz użytkownika");
                    return;
                }
            }
        }

        public string Task_ID
        {
            get
            {
                return task_ID;
            }
            set
            {
                if (value != null && value is String)
                {
                    task_ID = value;
                }
                else
                {
                    MessageBox.Show("Wybierz zadanie");
                    return;
                }
            }
        }

        public string ScheduleStatus_ID
        {
            get
            {
                return scheduleStatus_ID;
            }
            set
            {
                if (value != null && value is String)
                {
                    scheduleStatus_ID = value;
                }
                else
                {
                    MessageBox.Show("Przypisz status zadania");
                    return;
                }
            }
        }
        public DateTime DateSchedule { get => dateSchedule; set => dateSchedule = value; }


        public TimeSpan HourOfExecution { get => hourOfExecution; set => hourOfExecution = value; }


        public Schedule(string task_ID, string scheduleStatus_ID, TimeSpan hourOfExecution)
        {

            this.task_ID = task_ID;
            this.scheduleStatus_ID = scheduleStatus_ID;
            this.hourOfExecution = hourOfExecution;
        }
        
        public object[] ToObjTbl { get => new object[] { Task_ID, ScheduleStatus_ID, HourOfExecution }; }
    }
}