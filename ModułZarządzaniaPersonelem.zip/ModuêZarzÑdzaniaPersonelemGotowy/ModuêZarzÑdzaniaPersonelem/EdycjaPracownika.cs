﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using System.Configuration;

namespace ModułZarządzaniaPersonelem
{
    internal partial class EdycjaPracownika : Form
    {
        Thread th;

        User user;
        public EdycjaPracownika()
        {
            InitializeComponent();
        }
        
        public void RefreshDgv()
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.Tag == null)
                    continue;
                if (row.Tag.GetType() != typeof(User))
                    continue;

                User user = (User)row.Tag;

                for (int i = 0; i < row.Cells.Count; i++)
                    row.Cells[i].Value = user.ObjTbl[i];

            }          
        }

        private void EdycjaPracownika_Load(object sender, EventArgs e)
        {          
            odczyt();           
        }
        void odczyt()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString))
            {
                try
                {
                    con.Open();

                    string sql = "SELECT * FROM [User];";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    SqlDataReader rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        User user = new User((int)rdr[0], (string)rdr[1], (string)rdr[2], (string)rdr[3], (string)rdr[4], (string)rdr[5], (decimal)rdr[6], (decimal)rdr[7], (string)rdr[8]);
                        int row_index = dataGridView1.Rows.Add(user.ObjTbl2);
                        dataGridView1.Rows[row_index].Tag = user;



                    }
                    rdr.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "Niepowodzenie");
                }
                con.Close();
            }


        }

        void update(User user)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString))
            {

                try
                {
                    string query1 = "if (not exists(select * from [User] where firstName = @firstName AND lastName = @lastName " +
                        "AND login = @login AND passwordHash = @passwordHash AND codeHash = @codeHash AND baseSalary = @baseSalary " +
                        "AND hourlyRate = @hourlyRate AND permission = @permission)) begin update[User] SET firstName = @firstName, " +
                        "lastName = @lastName, login = @login, passwordHash = @passwordHash, codeHash = @codeHash, baseSalary = @baseSalary," +
                        " hourlyRate = @hourlyRate, permission = @permission where user_ID= @user_ID PRINT 'Zaktualizowano informacje' end else" +
                        " PRINT 'Podany pracownik już istnieje'";

                    using (SqlCommand cmd = new SqlCommand(query1, con))
                    {
                        cmd.Parameters.AddWithValue("@firstName", user.FirstName);
                        cmd.Parameters.AddWithValue("@lastName", user.LastName);
                        cmd.Parameters.AddWithValue("@login", user.Login);
                        cmd.Parameters.AddWithValue("@passwordHash", user.PasswordHash);
                        cmd.Parameters.AddWithValue("@codeHash", user.CodeHash);
                        cmd.Parameters.AddWithValue("@baseSalary", user.BaseSalary);
                        cmd.Parameters.AddWithValue("@hourlyRate", user.HourlyRate);
                        cmd.Parameters.AddWithValue("@permission", user.Permission);
                        cmd.Parameters.AddWithValue("@user_ID", user.User_Id);
                        con.Open();
                        con.InfoMessage += respondeMessage;
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "Niepowodzenie");
                }
            }

        }

        void respondeMessage(object sender, SqlInfoMessageEventArgs e)
        {
            var outputFromQuery = e.Message;
            MessageBox.Show(outputFromQuery.ToString());
        }

        private void dataGridView1_CellContentDoubleClick_1(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1_CellDoubleClick_1(sender, e);
        }

        private void dataGridView1_CellDoubleClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count != 1)
                return;
            if (dataGridView1.SelectedRows[0].Tag == null)
                return;
            if (dataGridView1.SelectedRows[0].Tag.GetType() != typeof(User))
                return;
            User user = (User)dataGridView1.SelectedRows[0].Tag;
            ZmieńDanePracownika zmien = new ZmieńDanePracownika(user);
            if (zmien.ShowDialog() != DialogResult.OK)
                return;

           

            RefreshDgv();
            update(user);

        }


        private void buttonWróć_Click(object sender, EventArgs e)
        {
            this.Dispose();
            th = new Thread(openForm);
            th.Start();
        }

        private void openForm()
        {
            Application.Run(new PanelMenadżera());
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buttonOdśwież_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            odczyt();
        }

        private void EdycjaPracownika_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                DialogResult res = MessageBox.Show("Czy na pewno chcesz zamknąć program?", "Zamykanie", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                {
                    if (res == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                        return;
                    }

                }
            }
        }
    }
}
