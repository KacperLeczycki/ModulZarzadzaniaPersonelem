﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Threading;
using System.Configuration;


namespace ModułZarządzaniaPersonelem
{
    internal partial class DodajPracownika : Form
    {
        Thread th;

        User user;
        public DodajPracownika()
        {
            InitializeComponent();
            this.user = user;

        }
        


        private void buttonZapiszDodajPracownika_Click(object sender, EventArgs e)
        {
            if (textBoxImięDodajPracownika.Text != String.Empty &&
                textBoxNazwiskoDodajPracownika.Text != String.Empty &&
                textBoxLoginDodajPracownika.Text != String.Empty &&
                textBoxHasłoDodajPracownika.Text != String.Empty &&
                textBoxPotwierdzHaslo.Text != String.Empty &&
                textBoxKodDodajPracownika.Text != String.Empty &&
                numericUpDownPensjaDodajPracownika.Value != 0 &&
                numericUpDownStawkaDodajPracownika.Value != 0 &&
                comboBoxUprawnieniaDodajPracownika.SelectedItem != null)
            {
                if (textBoxHasłoDodajPracownika.Text == textBoxPotwierdzHaslo.Text && textBoxHasłoDodajPracownika.Text.Length > 6)
                {
                    InsertUser();
                }
                else
                {
                    MessageBox.Show("Hasła nie są takie same lub podane hasło jest za krótkie");
                }
            }
            else
            {
                MessageBox.Show("Uzupełnij informacje");
            }
        }
        void InsertUser()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString))
            {
                try
                {
                    string query = "if (not exists(select * from [User] where firstName = @firstName AND lastName = @lastName " +
                         "AND login = @login AND passwordHash = @passwordHash AND codeHash = @codeHash AND baseSalary = @baseSalary " +
                         "AND hourlyRate = @hourlyRate AND permission = @permission)) " +
                         "begin insert into [User] (firstName,lastName,login,passwordHash,codeHash,baseSalary,hourlyRate,permission)" +
                         "values" +
                        "(@firstName, @lastName, @login, @passwordHash, @codeHash, @baseSalary, @hourlyRate, @permission) " +
                        "PRINT 'Dodano pracownika'end else PRINT 'Podany pracownik już istnieje'";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@firstName", textBoxImięDodajPracownika.Text);
                        cmd.Parameters.AddWithValue("@lastName", textBoxNazwiskoDodajPracownika.Text);
                        cmd.Parameters.AddWithValue("@login", textBoxLoginDodajPracownika.Text);
                        cmd.Parameters.AddWithValue("@passwordHash", textBoxHasłoDodajPracownika.Text);
                        cmd.Parameters.AddWithValue("@codeHash", textBoxKodDodajPracownika.Text);
                        cmd.Parameters.AddWithValue("@baseSalary", numericUpDownPensjaDodajPracownika.Value);
                        cmd.Parameters.AddWithValue("@hourlyRate", numericUpDownStawkaDodajPracownika.Value);
                        cmd.Parameters.AddWithValue("@permission", Convert.ToString(comboBoxUprawnieniaDodajPracownika.SelectedItem));
                        con.Open();
                        con.InfoMessage += respondeMessage;
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Niepowodzenie " + e.ToString());
                }
            }

            textBoxImięDodajPracownika.Clear();
            textBoxNazwiskoDodajPracownika.Clear();
            textBoxHasłoDodajPracownika.Clear();
            textBoxLoginDodajPracownika.Clear();
            textBoxKodDodajPracownika.Clear();
            textBoxPotwierdzHaslo.Clear();
            numericUpDownPensjaDodajPracownika.Value = 0;
            numericUpDownStawkaDodajPracownika.Value = 0;
            comboBoxUprawnieniaDodajPracownika.SelectedIndex = 0;

        }

        void respondeMessage(object sender, SqlInfoMessageEventArgs e)
        {
            var outputFromQuery = e.Message;
            MessageBox.Show(outputFromQuery.ToString());
        }

        private void textBoxImięDodajPracownika_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '`' || e.KeyChar == '~' || e.KeyChar == '!' || e.KeyChar == '@' ||
                e.KeyChar == '#' || e.KeyChar == '$' || e.KeyChar == '%' || e.KeyChar == '^' ||
                e.KeyChar == '&' || e.KeyChar == '*' || e.KeyChar == '(' || e.KeyChar == ')' ||
                e.KeyChar == '-' || e.KeyChar == '_' || e.KeyChar == '=' || e.KeyChar == '+' ||
                e.KeyChar == '/' || e.KeyChar == '[' || e.KeyChar == '{' || e.KeyChar == ']' ||
                e.KeyChar == '}' || e.KeyChar == '|' || e.KeyChar == ';' || e.KeyChar == ':' ||
                e.KeyChar == '"' || e.KeyChar == ',' || e.KeyChar == '<' || e.KeyChar == '.' ||
                e.KeyChar == '>' || e.KeyChar == '?' || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = true;
            }

            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || e.KeyChar == '4' ||
               e.KeyChar == '5' || e.KeyChar == '6' || e.KeyChar == '7' || e.KeyChar == '8'
               || e.KeyChar == '9' || e.KeyChar == '0')
            {
                e.Handled = true;
            }
        }

        private void textBoxNazwiskoDodajPracownika_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '`' || e.KeyChar == '~' || e.KeyChar == '!' || e.KeyChar == '@' ||
                e.KeyChar == '#' || e.KeyChar == '$' || e.KeyChar == '%' || e.KeyChar == '^' ||
                e.KeyChar == '&' || e.KeyChar == '*' || e.KeyChar == '(' || e.KeyChar == ')' ||
                e.KeyChar == '-' || e.KeyChar == '_' || e.KeyChar == '=' || e.KeyChar == '+' ||
                e.KeyChar == '/' || e.KeyChar == '[' || e.KeyChar == '{' || e.KeyChar == ']' ||
                e.KeyChar == '}' || e.KeyChar == '|' || e.KeyChar == ';' || e.KeyChar == ':' ||
                e.KeyChar == '"' || e.KeyChar == ',' || e.KeyChar == '<' || e.KeyChar == '.' ||
                e.KeyChar == '>' || e.KeyChar == '?' || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = true;
            }

            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || e.KeyChar == '4' ||
               e.KeyChar == '5' || e.KeyChar == '6' || e.KeyChar == '7' || e.KeyChar == '8'
               || e.KeyChar == '9' || e.KeyChar == '0')
            {
                e.Handled = true;
            }
        }

        private void textBoxLoginDodajPracownika_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'ą' || e.KeyChar == 'ę' || e.KeyChar == 'ś' || e.KeyChar == 'ł' || 
                e.KeyChar == 'ż' || e.KeyChar == 'ź' || e.KeyChar == 'ć' || e.KeyChar == 'ń' || e.KeyChar == 'ó' ||
                e.KeyChar == (char)Keys.Space)
            {
                e.Handled = true;
            }
        }

        private void textBoxHasłoDodajPracownika_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'ą' || e.KeyChar == 'ę' || e.KeyChar == 'ś' || e.KeyChar == 'ł' ||
                e.KeyChar == 'ż' || e.KeyChar == 'ź' || e.KeyChar == 'ć' || e.KeyChar == 'ń' || e.KeyChar == 'ó' ||
                e.KeyChar == (char)Keys.Space)
            {
                e.Handled = true;
            }
        }

        private void textBoxKodDodajPracownika_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Space)
            {
                e.Handled = true;
            }
        }

        private void comboBoxUprawnieniaDodajPracownika_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '`' || e.KeyChar == '~' || e.KeyChar == '!' || e.KeyChar == '@' ||
                e.KeyChar == '#' || e.KeyChar == '$' || e.KeyChar == '%' || e.KeyChar == '^' ||
                e.KeyChar == '&' || e.KeyChar == '*' || e.KeyChar == '(' || e.KeyChar == ')' ||
                e.KeyChar == '-' || e.KeyChar == '_' || e.KeyChar == '=' || e.KeyChar == '+' ||
                e.KeyChar == '/' || e.KeyChar == '[' || e.KeyChar == '{' || e.KeyChar == ']' ||
                e.KeyChar == '}' || e.KeyChar == '|' || e.KeyChar == ';' || e.KeyChar == ':' ||
                e.KeyChar == '"' || e.KeyChar == ',' || e.KeyChar == '<' || e.KeyChar == '.' ||
                e.KeyChar == '>' || e.KeyChar == '?' || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = true;
            }

            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || e.KeyChar == '4' ||
               e.KeyChar == '5' || e.KeyChar == '6' || e.KeyChar == '7' || e.KeyChar == '8'
               || e.KeyChar == '9' || e.KeyChar == '0')
            {
                e.Handled = true;
            }
        }

        private void DodajPracownika_Load(object sender, EventArgs e)
        {

        }

        private void buttonWróć_Click(object sender, EventArgs e)
        {
            this.Dispose();
            th = new Thread(openForm);
            th.Start();
        }

        private void openForm()
        {
                Application.Run(new PanelMenadżera());
        }

        private void checkBoxPokazHaslo_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBoxPokazHaslo.Checked == true)
            {
                textBoxHasłoDodajPracownika.PasswordChar = '\0';
                textBoxPotwierdzHaslo.PasswordChar = '\0';
            }
            else
            {
                textBoxHasłoDodajPracownika.PasswordChar = '*';
                textBoxPotwierdzHaslo.PasswordChar = '*';
            }
        }

        private void DodajPracownika_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                DialogResult res = MessageBox.Show("Czy na pewno chcesz zamknąć program?", "Zamykanie", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                {
                    if (res == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                        return;
                    }

                }
            }
        }
    }
}
