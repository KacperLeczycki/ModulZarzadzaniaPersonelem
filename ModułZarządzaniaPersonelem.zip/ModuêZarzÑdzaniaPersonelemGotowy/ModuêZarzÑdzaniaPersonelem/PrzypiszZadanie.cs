﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using System.Configuration;

namespace ModułZarządzaniaPersonelem
{
    public partial class PrzypiszZadanie : Form
    {
        Thread th;
        public PrzypiszZadanie()
        {
            InitializeComponent();
            refreshdata();
            refreshdata2();

        }
        
        public void refreshdata()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("select * from Task", con);
                    SqlDataReader Sdr = cmd.ExecuteReader();
                    while (Sdr.Read())
                    {
                        Task schS = new Task();
                        schS.NameTask = (string)Sdr[1];
                        schS.Description = (string)Sdr[2];
                        int cmb = comboBoxOpisZadania.Items.Add(schS.ToString());
                        comboBoxOpisZadania.SelectedItem = schS;
                    }
                    Sdr.Close();
                    con.Close();
                }
                catch (Exception e)
                {
                    MessageBox.Show("Niepowodzenie " + e.ToString());
                }
            }
        }
              
        public void refreshdata2()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("select * from ScheduleStatus", con);
                    SqlDataReader Sdr = cmd.ExecuteReader();
                    while (Sdr.Read())
                    {
                        ScheduleStatus schS = new ScheduleStatus((int)Sdr[0], (string)Sdr[1]);
                        int cmb = comboBoxStatusZadania.Items.Add(schS.ToString());
                        comboBoxStatusZadania.SelectedItem = schS;
                    }
                    Sdr.Close();
                    con.Close();
                }
                catch (Exception e)
                {
                    MessageBox.Show("Niepowodzenie " + e.ToString());
                }
            }
        }

        private void PrzypiszZadanie_Load(object sender, EventArgs e)
        {
            // TODO: Ten wiersz kodu wczytuje dane do tabeli 'modułZarządzaniaPersonelemDataSet4.User' . Możesz go przenieść lub usunąć.
            this.userTableAdapter.Fill(this.modułZarządzaniaPersonelemDataSet4.User);

            dateTimePicker1.MinDate = DateTime.Now;       

            TimeToText1();
            TimeToText2();
        }

        void TimeToText1()
        {
            string a = Convert.ToString(numericUpDownGodzina.Value);


            if (numericUpDownGodzina.Value < 10)
            {
                string c = "0" + a;
                textBoxGodzina.Text = c;

            }
            else if (numericUpDownGodzina.Value >= 10)
            {
                textBoxGodzina.Text = a;
            }

        }

        void TimeToText2()
        {
            string b = Convert.ToString(numericUpDownMinuty.Value);


            if (numericUpDownMinuty.Value < 10)
            {
                string c = "0" + b;
                textBoxMinuty.Text = c;

            }
            else if (numericUpDownMinuty.Value >= 10)
            {
                textBoxMinuty.Text = b;
            }
        }

        private void numericUpDownGodzina_ValueChanged(object sender, EventArgs e)
        {
            TimeToText1();
        }

        private void numericUpDownMinuty_ValueChanged(object sender, EventArgs e)
        {
            TimeToText2();
        }

        private void buttonPrzypiszZadanie_Click(object sender, EventArgs e)
        {
            if (textBoxImię.Text != string.Empty && textBoxNazwisko.Text != string.Empty && comboBoxOpisZadania.SelectedItem != null
                && comboBoxStatusZadania.SelectedItem != null)
            {            
                    AssignTask();              
            }
            else
            {
                MessageBox.Show("Uzupełnij informacje");
            }
        
        }

        void AssignTask()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString))
            {
                try
                {
                    string query = " set dateformat dmy if(not exists (select * from Schedule where " +
                        "user_ID = (select user_ID from[User] where firstName = @firstName " +
                        "AND lastName = @lastName) AND dateSchedule = @dateSchedule " +
                        "AND task_ID = (select task_ID from Task where description = @description) " +
                        "AND scheduleStatus_ID = (select scheduleStatus_ID " +
                        "from ScheduleStatus where nameStatus = @nameStatus) " +
                        "AND hourOfExecution = @hourOfExecution)) begin insert into Schedule(user_ID, task_ID, " +
                        "dateSchedule, scheduleStatus_ID, hourOfExecution) values((select user_ID from[User] " +
                        "where firstName = @firstName AND lastName = @lastName),(select task_ID from Task " +
                        "where description = @description),@dateSchedule,(select scheduleStatus_ID from " +
                        "ScheduleStatus where nameStatus = @nameStatus), @hourOfExecution) " +
                        "PRINT 'Przydzielono zadanie' end else PRINT 'Zadanie zostało już wcześniej przydzielone'";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@firstName", textBoxImię.Text);
                        cmd.Parameters.AddWithValue("@lastName", textBoxNazwisko.Text);
                        cmd.Parameters.AddWithValue("@description", comboBoxOpisZadania.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@dateSchedule", dateTimePicker1.Value.ToShortDateString());
                        cmd.Parameters.AddWithValue("@nameStatus", comboBoxStatusZadania.SelectedItem.ToString());

                        string hr = textBoxGodzina.Text;
                        string min = textBoxMinuty.Text;
                        string time = hr + ":" + min;
                        cmd.Parameters.Add("@hourOfExecution", SqlDbType.Time).Value = TimeSpan.Parse(time);
                        con.Open();
                        con.InfoMessage += respondeMessage;
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Niepowodzenie " + e.ToString());
                }
            }
        }

        void respondeMessage(object sender, SqlInfoMessageEventArgs e)
        {
            var outputFromQuery = e.Message;
            MessageBox.Show(outputFromQuery.ToString());
        }

        private void buttonWróc_Click(object sender, EventArgs e)
        {
            this.Dispose();
            th = new Thread(openForm);
            th.Start();
        }

        private void openForm()
        {
            Application.Run(new PanelMenadżera());
        }

        private void PrzypiszZadanie_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                DialogResult res = MessageBox.Show("Czy na pewno chcesz zamknąć program?", "Zamykanie", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                {
                    if (res == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                        return;
                    }

                }
            }
        }
    }
}
