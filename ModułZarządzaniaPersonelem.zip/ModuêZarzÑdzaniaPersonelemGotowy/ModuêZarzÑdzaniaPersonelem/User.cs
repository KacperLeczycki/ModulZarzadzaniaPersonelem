﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ModułZarządzaniaPersonelem
{
    class User
    {
        int user_ID;

        string firstName;

        string lastName;

        string login;

        string passwordHash;

        string codeHash;

        decimal baseSalary;

        decimal hourlyRate;

        string permission;

        public string FirstName
        {
            get
            {
                return firstName;
            }
            set
            {
                if (value != null && value is String)
                {
                    firstName = value;
                }
                else
                {
                    MessageBox.Show("Uzupełnij imię");
                    return;
                }
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                if (value != null && value is String)
                {
                    lastName = value;
                }
                else
                {
                    MessageBox.Show("Uzupełnij nazwisko");
                    return;
                }
            }
        }

        public decimal BaseSalary
        {
            get
            {
                return baseSalary;
            }
            set
            {
                if (value > 0.00M)
                {
                    baseSalary = value;
                }
                else
                {
                    MessageBox.Show("Uzupełnij pensję");
                    return;
                }
            }


        }

        public decimal HourlyRate
        {
            get
            {
                return hourlyRate;
            }
            set
            {
                if (value > 0.00M)
                {
                    hourlyRate = value;
                }
                else
                {
                    MessageBox.Show("Uzupełnij stawkę godzinową");
                    return;
                }
            }
        }

        public string Permission
        {
            get
            {
                return permission;
            }
            set
            {
                if (value != null && value is String)
                {
                    permission = value;
                }
                else
                {
                    MessageBox.Show("Przypisz uprawnienia");
                    return;
                }
            }
        }

        public string Login
        {
            get
            {
                return login;
            }
            set
            {
                if (value != null)
                {
                    login = value;
                }
                else
                {
                    MessageBox.Show("Uzupełnij login");
                    return;
                }
            }
        }

        public string PasswordHash
        {
            get
            {
                return passwordHash;
            }
            set
            {
                if (value != null)
                {
                    passwordHash = value;
                }
                else
                {
                    MessageBox.Show("Uzupełnij hasło");
                    return;
                }
            }
        }
        public string CodeHash
        {
            get
            {
                return codeHash;
            }
            set
            {
                if (value != null)
                {
                    codeHash = value;
                }
                else
                {
                    MessageBox.Show("Uzupełnij kod");
                    return;
                }
            }
        }
        public int User_Id { get => user_ID; }


        public User(int user_ID, string firstName, string lastName, string login, string passwordHash, string codeHash, decimal baseSalary, decimal hourlyRate, string permission)
        {
            this.user_ID = user_ID;
            this.firstName = firstName;
            this.lastName = lastName;
            this.login = login;
            this.passwordHash = passwordHash;
            this.codeHash = codeHash;
            this.baseSalary = baseSalary;
            this.hourlyRate = hourlyRate;
            this.permission = permission;
        }

        public object[] ObjTbl { get => new object[] { FirstName, LastName, Login, PasswordHash, CodeHash, BaseSalary, HourlyRate, Permission }; }

        public object[] ObjTbl2 { get => new object[] { FirstName, LastName }; }

        public override string ToString()
        {
            return FirstName + " " + LastName;
        }

    }
}